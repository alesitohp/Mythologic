package Juego;

import java.util.ArrayList;
import java.util.Scanner;

public class combate {
	private static Warrior guerrero = new Warrior(40, 20, 5, 0, "Link", "Hacha", 5);// hp=40, atack=5
	private static Orco orco = new Orco("Pepe", 4, 20, 4);// hp=20, atack=4
	private static Scanner scan = new Scanner(System.in);
	private static int huir = 9;
	private static ArrayList<Pociones> pociones = new ArrayList<>();

	public static void iniciarAplicacion() {
		iniciarPociones();
		iniciarcombate();
	}

	private static void iniciarcombate() {
		do {
			mostrarMenu();
			int opcion = scan.nextInt();

			switch (opcion) {
			case 1:
				atacar();
				break;

			case 2:
				defender();
				break;

			case 3:
				mostrarPociones();
				break;

			case 4:
				usarPociones();
				break;

			case 5:
				huir=(int) (Math.random()*3);
				if(huir != 2) {
					System.out.println("No has podido huir");
					atacarEnemigo(guerrero, orco);
				}
				break;
			}
		} while ((orco.getHp() > 0) && (guerrero.getHp() > 0) && (huir != 2));

		if (huir == 2) {
			System.out.println("Has huido");
		}
		else if ((guerrero.getHp() > 0)) {
			System.out.println("El orco enemigo ha sido derrotado");
		} else if ((orco.getHp() > 0)) {
			System.out.println("El guerrero aliado ha sido derrotado");
			System.exit(0);
		}

		int opcion; // opcion del menu fuera de combate

		do {
			MostrarMenuFueraCombate();
			opcion = scan.nextInt();
			switch (opcion) {
			case 1:
				resetearEnemigo();
				iniciarcombate();
				break;

			case 2:
				usarPociones();
				break;

			}
		} while (opcion != 3);
	}

	private static void mostrarMenu() {
		System.out.println("1)Atacar");
		System.out.println("2)Defender");
		System.out.println("3)Mirar objetos");
		System.out.println("4)Usar un objeto");
		System.out.println("5)Huir");

	}

	private static void atacarAliado(Warrior guerrero, Orco orco) {
		if (guerrero.getHp() > 0) {
			System.out.println("El aliado ataca e inflinje " + guerrero.getAtack() + " de da�o al orco enemigo");
			orco.setHp(orco.getHp() - guerrero.getAtack());
			System.out.println("Al orco enemigo le quedan " + orco.getHp() + "hp");
			System.out.println();
		}

	}

	private static void atacarEnemigo(Warrior guerrero, Orco orco) {
		if (orco.getHp() > 0) {
			System.out.println("El orco enemigo ataca e inflinje " + orco.getAtack() + " de da�o al aliado");
			guerrero.setHp(guerrero.getHp() - orco.getAtack());
			System.out.println("Al aliado le quedan " + guerrero.getHp() + "hp");
			System.out.println();
		}

	}

	private static void defender() {
		System.out.println("El guerrero se defiende");
		orco.setAtack(orco.getAtack() - 2);
		atacarEnemigo(guerrero, orco);
		orco.setAtack(orco.getAtack() + 2);
	}

	private static void MostrarMenuFueraCombate() {
		System.out.println("1)Combatir");
		System.out.println("2)Usar una pocion");
		System.out.println("3)Dejar de jugar");
	}

	private static void resetearEnemigo() {
		orco.setNombre("Orco");
		orco.setAtack(4);
		orco.setHp(20);
		orco.setLvl(4);
	}

	private static void atacar() {
		if (guerrero.getLvl() > orco.getLvl()) {
			atacarAliado(guerrero, orco);
			atacarEnemigo(guerrero, orco);
		} else {
			atacarEnemigo(guerrero, orco);
			atacarAliado(guerrero, orco);
		}
	}

	private static void iniciarPociones() {
		PocionPeque�a pocionpeque�a = new PocionPeque�a("Pocion peque�a", 10, 5);
		PocionGrande pociongrande = new PocionGrande("Pocion grande", 10, 10);
		pociones.add(pociongrande);
		pociones.add(pocionpeque�a);
	}

	private static void mostrarPociones() {
		for (int i = 0; i < pociones.size(); i++) {
			System.out.println(pociones.get(i).toString());
		}
		System.out.println();
	}

	private static void usarPociones() {
		System.out.println("Que pocion quieres usar? 1-Pocion Peque�a 2-Pocion Grande");
		int opcion = scan.nextInt();

		if (opcion == 1) {
			pociones.get(1).setCantidad(pociones.get(1).getCantidad() - 1);
			guerrero.setHp(guerrero.getHp() + 5);
			System.out.println("El guerrero se ha curado 5hp");
			System.out.println("Vida actual: " + guerrero.getHp());
		} else if (opcion == 2) {
			pociones.get(0).setCantidad(pociones.get(0).getCantidad() - 1);
			guerrero.setHp(guerrero.getHp() + 10);
			System.out.println("El guerrero se ha curado 10hp");
			System.out.println("Vida actual: " + guerrero.getHp());
		}
		atacarEnemigo(guerrero, orco);
	}

}
