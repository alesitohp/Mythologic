package Juego;

public class Personajes_enemigos {
	private String nombre;
	private float atack;
	private float hp;
	private float lvl;
	public Personajes_enemigos(String nombre, float atack, float hp, float lvl) {
		super();
		this.nombre = nombre;
		this.atack = atack;
		this.hp = hp;
		this.lvl = lvl;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public float getAtack() {
		return atack;
	}
	public void setAtack(float atack) {
		this.atack = atack;
	}
	public float getHp() {
		return hp;
	}
	public void setHp(float hp) {
		this.hp = hp;
	}
	public float getLvl() {
		return lvl;
	}
	public void setLvl(float lvl) {
		this.lvl = lvl;
	}
	@Override
	public String toString() {
		return "Personajes_enemigos [nombre=" + nombre + ", atack=" + atack + ", hp=" + hp + ", lvl=" + lvl + "]";
	}
	
	
	
	
}
