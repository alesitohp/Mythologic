package Juego;

public class PocionGrande extends Pociones{
	private int curar;

	public PocionGrande(String nombre, int cantidad, int curar) {
		super(nombre, cantidad);
		this.curar = curar;
	}

	public int getCurar() {
		return curar;
	}

	public void setCurar(int curar) {
		this.curar = curar;
	}

	@Override
	public String toString() {
		return "PocionGrande [curar=" + curar + " cantidad = " + super.getCantidad() + "]";
	}
	

}
