package Juego;

public class PocionPeque�a extends Pociones{
	private int cura;

	public PocionPeque�a(String nombre, int cantidad, int cura) {
		super(nombre, cantidad);
		this.cura = cura;
	}

	public int getCura() {
		return cura;
	}

	public void setCura(int cura) {
		this.cura = cura;
	}

	@Override
	public String toString() {
		return "PocionPeque�a [cura=" + cura + " cantidad = " + super.getCantidad() +"]";
	}
	
	
}
