package Juego;

public class Warrior extends Personajes_aliado{
	private String weapong;
	private float atack;
	public Warrior(float hp, float pm, float lvl, float exp, String nombre, String weapong, float atack) {
		super(hp, pm, lvl, exp, nombre);
		this.weapong = weapong;
		this.atack = atack;
	}
	public String getWeapong() {
		return weapong;
	}
	public void setWeapong(String weapong) {
		this.weapong = weapong;
	}
	public float getAtack() {
		return atack;
	}
	public void setAtack(float atack) {
		this.atack = atack;
	}
	@Override
	public String toString() {
		return "Warrior [weapong=" + weapong + ", atack=" + atack + "]";
	}
	
	

	
	
	
}
