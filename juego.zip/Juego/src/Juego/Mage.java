package Juego;

public class Mage extends Personajes_aliado{
	private String weapong;
	private String speels;
	private float atack;
	public Mage(float hp, float pm, float lvl, float exp, String nombre, String weapong, String speels, float atack) {
		super(hp, pm, lvl, exp, nombre);
		this.weapong = weapong;
		this.speels = speels;
		this.atack = atack;
	}
	public String getWeapong() {
		return weapong;
	}
	public void setWeapong(String weapong) {
		this.weapong = weapong;
	}
	public String getSpeels() {
		return speels;
	}
	public void setSpeels(String speels) {
		this.speels = speels;
	}
	public float getAtack() {
		return atack;
	}
	public void setAtack(float atack) {
		this.atack = atack;
	}
	@Override
	public String toString() {
		return "Mage [weapong=" + weapong + ", speels=" + speels + ", atack=" + atack + "]";
	}
	
	
	
	
	
	
	
}
