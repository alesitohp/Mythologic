package Juego;

public class Personajes_aliado {
	private float hp;
	private float pm;
	private float lvl;
	private float exp;
	private String nombre;
	public Personajes_aliado(float hp, float pm, float lvl, float exp, String nombre) {
		super();
		this.hp = hp;
		this.pm = pm;
		this.lvl = lvl;
		this.exp = exp;
		this.nombre = nombre;
	}
	public float getHp() {
		return hp;
	}
	public void setHp(float hp) {
		this.hp = hp;
	}
	public float getPm() {
		return pm;
	}
	public void setPm(float pm) {
		this.pm = pm;
	}
	public float getLvl() {
		return lvl;
	}
	public void setLvl(float lvl) {
		this.lvl = lvl;
	}
	public float getExp() {
		return exp;
	}
	public void setExp(float exp) {
		this.exp = exp;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Personajes_aliado [hp=" + hp + ", pm=" + pm + ", lvl=" + lvl + ", exp=" + exp + ", nombre=" + nombre
				+ "]";
	}
	
	
}
