package Juego;

public class Lista_Errores {
	/*
		1)Generar un nuevo enemigo al morir el anterior
		2)Controlar las pocione que no bajen de 0
		3)Arreglar mensaje finalizar combate
		
	
	
		huir = (int) (Math.random() * 2);
				if (huir != 0) {
					System.out.println("No has podido escapar");
					atacarEnemigo(guerrero, orco);
					
					A�adir ubicacion al acabar el combate
*/				
	
	
	
}
