package Juego;

public class Orco extends Personajes_enemigos{

	public Orco(String nombre, float atack, float hp, float lvl) {
		super(nombre, atack, hp, lvl);
		// TODO Auto-generated constructor stub
	}

	
	
}
